/** Automatically generated file. DO NOT MODIFY */
package eindp.helikopter.hekoco;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}