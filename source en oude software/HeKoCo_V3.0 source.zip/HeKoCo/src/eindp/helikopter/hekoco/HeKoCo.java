package eindp.helikopter.hekoco;



import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
//import java.io.BufferedInputStream;
import java.util.List;
import java.util.UUID;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;



import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
//import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

public class HeKoCo extends Activity{
	// Intent request codes
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    private static final int REQUEST_ENTER_PID = 3;
	private static final int REQUEST_SENSOR = 4;
	
	public static boolean sensormodus = false;
	public static boolean pidprogmodus = false;
    protected static final int MOVE_TIME = 80;
	private static boolean connectStat = false;
	Button rechts;
	Button links;
	Button voor;
	Button achter;
	Button pidlezen;
	Button pidschrijven;
	//Button send;
	MenuItem connectitem;
	EditText pText;
	EditText iText;
	EditText dText;
	//EditText message;
	SeekBar throttleBar;
	SeekBar voorAchterBar;
	SeekBar stuurBar;
	TextView sterkte;
	TextView stuurSterkte;
	TextView sturenoffset;
	TextView vaoffset;
	TextView voorAchterSterkte;
	TextView debug;
	String orient = "Midden";
	String va = "Stil";
	View controlView;
	View instelView;
	String debugString = "Debug";
	int sterkte_value = 0;
	int stuur_value_init = 50;
	int knop_stuur_value = 25;
	int va_value_init = 50;
	int knop_va_value = 25;
	Float pValue;
	Float iValue;
	Float dValue;
	private Toast failToast;
    private Handler mHandler;
    ProgressDialog myProgressDialog;
    private long lastWrite = 0;
    
 // Sensor object used to handle accelerometer
    private SensorManager mySensorManager; 
    private List<Sensor> sensors; 
    private Sensor accSensor;
    
	// Bluetooth Stuff
	private BluetoothAdapter mBluetoothAdapter;
	private BluetoothSocket btSocket = null; 
    private static OutputStream outStream = null;
    //private BufferedInputStream binStream;
    private ConnectThread mConnectThread = null;
    private String deviceAddress = null;
	
    // Well known SPP UUID (will *probably* map to RFCOMM channel 1 (default) if not in use); 
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
	public static final String TAG = "tag";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Layout maken
        LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        
        controlView = inflater.inflate(R.layout.main, null);
        //instelView = inflater.inflate(R.layout.instellen, null);
        controlView.setKeepScreenOn(true);
        //instelView.setKeepScreenOn(true);
        //setContentView(instelView);
        setContentView(controlView);
        
        //Layout elementen vinden met hun id zodat ze gebruikt kunnen worden
        sterkte = (TextView)findViewById(R.id.sterkte);
        stuurSterkte = (TextView)findViewById(R.id.stuurSterkte);
        sturenoffset = (TextView)findViewById(R.id.sturenText);
        vaoffset = (TextView)findViewById(R.id.offsetVA);
        voorAchterSterkte = (TextView)findViewById(R.id.voorAchterSterkte);
        debug = (TextView)findViewById(R.id.debug);
        
        rechts = (Button)findViewById(R.id.buttonRechts);
        links = (Button)findViewById(R.id.buttonLinks);
        voor = (Button)findViewById(R.id.voorButton);
        achter = (Button)findViewById(R.id.achterButton);
        //send = (Button)findViewById(R.id.send);
        
        throttleBar = (SeekBar)findViewById(R.id.throttleBar);
        stuurBar = (SeekBar)findViewById(R.id.stuurBar);
        voorAchterBar = (SeekBar)findViewById(R.id.voorAchterBar);
        
        //message =(EditText)findViewById(R.id.message);
        
        connectitem = (MenuItem)findViewById(R.id.connect);
        
        //Listeners maken voor de schuifbalken
        throttleBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
        	@Override
        	public void onProgressChanged(SeekBar seekBar, int pos, boolean fromTouch) {
        		sterkte.setText("Sterkte: " + (pos));
        		sterkte_value = pos;
        		if (!pidprogmodus) {
					write((byte) 'l'); //omhoog omlaag
					write((byte) pos);
				}
        	}
        	@Override
        	public void onStartTrackingTouch(SeekBar seekBar) {
        	}
        	@Override
        	public void onStopTrackingTouch(SeekBar seekBar) {
        	}
        });
        voorAchterBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){

			@Override
			public void onProgressChanged(SeekBar seekBar, int pos, boolean fromTouch) {
				if(pos == va_value_init){ //Kijken waar de bar is
        			va = "Stil";
        		} else if (pos < va_value_init){
        			va = "Achter";
        		} else if (pos > va_value_init){
        			va = "Voor" ;
        		}
				voorAchterSterkte.setText("Staart Sterkte: " + pos + " Richting: " + va); //wegschrijven naar UI
				
				if (!pidprogmodus) {
					write((byte) 's'); //voor achter byte
					write((byte) pos);
				}
				
			}
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				
			}
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				//voorAchterBar.setProgress(50);
				//write((byte) 0);
			}
        });
        stuurBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener(){
        	@Override
        	public void onProgressChanged(SeekBar seekBar, int pos, boolean fromTouch) {
        		if(pos == stuur_value_init){
        			orient = "Midden";
        		} else if (pos < stuur_value_init){
        			orient = "Links";
        		} else if (pos > stuur_value_init){
        			orient = "Rechts" ;
        		}
        		stuurSterkte.setText("Stuur Sterkte: " + (pos - 50) +" Kant: " + orient);
        		if (!pidprogmodus) {
					write((byte) 'd'); //stuur byte
					write((byte) (pos - 50));
				}
        		
        	}
        	@Override
        	public void onStartTrackingTouch(SeekBar seekBar) {
        	}
        	@Override
        	public void onStopTrackingTouch(SeekBar seekBar) {
        		//stuurBar.setProgress(stuur_value_init); //Zet regelaar weer in het midden
        		//write((byte)0);
        	}
        });
        
        //Listeners maken voor de knopjes
        voor.setOnTouchListener(new OnTouchListener(){

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int p = 0;
				if(event.getAction() == MotionEvent.ACTION_DOWN){
					if(p == 0){
						va_value_init++;
						vaoffset.setText("Offset: " + va_value_init);
						p = 1;
					}
				} else if(event.getAction() == MotionEvent.ACTION_UP) {
					p = 0;
				}
				return false;
			}
        	
        });
        achter.setOnTouchListener(new OnTouchListener(){

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int p = 0;
				if(event.getAction() == MotionEvent.ACTION_DOWN){
					if(p == 0){
						va_value_init--;
						vaoffset.setText("Offset: " + va_value_init);
						p = 1;
					}
				} else if(event.getAction() == MotionEvent.ACTION_UP) {
					p = 0;
				}
				return false;
			}
        });
        
        rechts.setOnTouchListener(new OnTouchListener(){

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int p = 0;
				if(event.getAction() == MotionEvent.ACTION_DOWN){
					if(p == 0){
						stuur_value_init++;
						sturenoffset.setText("Offset: " + (stuur_value_init-50));
						p = 1;
					}
				} else if(event.getAction() == MotionEvent.ACTION_UP) {
					p = 0;
				}
				return false;
			}
        });
        links.setOnTouchListener(new OnTouchListener(){

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				int p = 0;
				if(event.getAction() == MotionEvent.ACTION_DOWN){
					if(p == 0){
						stuur_value_init--;
						sturenoffset.setText("Offset: " + (stuur_value_init-50));
						p = 1;
					}
				} else if(event.getAction() == MotionEvent.ACTION_UP) {
					p = 0;
				}
				return false;
			}
        });
        
        // Set Sensor
        mySensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE); 
        sensors = mySensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER); 
        if(sensors.size() > 0) accSensor = sensors.get(0); 
        
        /*send.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				message.getText().toString();
			}
        
        });*/
        
        myProgressDialog = new ProgressDialog(this);
        failToast = Toast.makeText(this, R.string.failedToConnect, Toast.LENGTH_SHORT);
        
        mHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
           	 if (myProgressDialog.isShowing()) {
                	myProgressDialog.dismiss();
                }
           	 
           	 // Check if bluetooth connection was made to selected device
                if (msg.what == 1) {
                	// Set button to display current status
                    connectStat = true;
                    //connectitem.setTitle(R.string.connected);
                    
                }else {
                	// Connection failed
               	 failToast.show();
                }
            }
        };
        
     // Check whether bluetooth adapter exists
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter(); 
        if (mBluetoothAdapter == null) { 
             Toast.makeText(this, R.string.no_bt_device, Toast.LENGTH_LONG).show(); 
             finish(); 
             return; 
        }
        
        // If BT is not on, request that it be enabled.
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        }
        
    }
    
    /** Thread used to connect to a specified Bluetooth Device */
	public class ConnectThread extends Thread {
	private String address;
	private boolean connectionStatus;

		ConnectThread(String MACaddress) {
			address = MACaddress;
			connectionStatus = true;
	}
		
		public void run() {
		// When this returns, it will 'know' about the server, 
	       // via it's MAC address. 
			try {
				BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
				
				// We need two things before we can successfully connect 
	            // (authentication issues aside): a MAC address, which we 
	            // already have, and an RFCOMM channel. 
	            // Because RFCOMM channels (aka ports) are limited in 
	            // number, Android doesn't allow you to use them directly; 
	            // instead you request a RFCOMM mapping based on a service 
	            // ID. In our case, we will use the well-known SPP Service 
	            // ID. This ID is in UUID (GUID to you Microsofties) 
	            // format. Given the UUID, Android will handle the 
	            // mapping for you. Generally, this will return RFCOMM 1, 
	            // but not always; it depends what other BlueTooth services 
	            // are in use on your Android device. 
	            try { 
	                 btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID); 
	            } catch (IOException e) { 
	            	connectionStatus = false;
	            } 
	    		
			}catch (IllegalArgumentException e) {
				connectionStatus = false;
			}
	       
	       // Discovery may be going on, e.g., if you're running a 
	       // 'scan for devices' search from your handset's Bluetooth 
	       // settings, so we call cancelDiscovery(). It doesn't hurt 
	       // to call it, but it might hurt not to... discovery is a 
	       // heavyweight process; you don't want it in progress when 
	       // a connection attempt is made. 
	       mBluetoothAdapter.cancelDiscovery(); 
	       
	       // Blocking connect, for a simple client nothing else can 
	       // happen until a successful connection is made, so we 
	       // don't care if it blocks. 
	       try {
	            btSocket.connect(); 
	            //Maken van Listener
	            BluetoothSocketListener bsl = new BluetoothSocketListener(btSocket,
	    				mHandler);
	    		Thread messageListener = new Thread(bsl);
	    		messageListener.start();
	       } catch (IOException e1) {
	            try {
	                 btSocket.close(); 
	            } catch (IOException e2) {
	            }
	       }
	       
	       // Create a data stream so we can talk to server. 
	       try { 
	       	outStream = btSocket.getOutputStream();
	       	//RecieveThread ontvanger = new RecieveThread();
	       	//ontvanger.start();
	       } catch (IOException e2) {
	       	connectionStatus = false;
	       }
	       
	       // Send final result
	       if (connectionStatus) {
	       	mHandler.sendEmptyMessage(1);
	       }else {
	       	mHandler.sendEmptyMessage(0);
	       }
		}
	}
	
	/*public class RecieveThread extends Thread{
		public void run(){
			byte[] buffer = new byte[1024];
            int bytes;
            while (true) {
                try {
                    // Read from the InputStream
                    bytes = inStream.read(buffer);
                    if(bytes > 0){
                    	debugString = ("a");
                    }
                    
                } catch (IOException e) {
                	
                    break;
                }
            }
		}
	}*/
	
	public void instellen(){
    	Intent serverIntent = new Intent(this, instellen.class);
    	startActivityForResult(serverIntent, REQUEST_ENTER_PID);
    }
	
	public void sensoren(){
		Intent serverIntent = new Intent(this, sensoren.class);
    	startActivityForResult(serverIntent, REQUEST_SENSOR);
	}
	
    public static boolean getConnectStat(){
		return connectStat;
    	
    }
    
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
   	 switch (requestCode) {
        case REQUEST_CONNECT_DEVICE:
       	 // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
           	// Show please wait dialog
				myProgressDialog = ProgressDialog.show(this, getResources().getString(R.string.pleaseWait), getResources().getString(R.string.makingConnectionString), true);
				
           	// Get the device MAC address
       		deviceAddress = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
       		// Connect to device with specified MAC address
               mConnectThread = new ConnectThread(deviceAddress);
               mConnectThread.start();
               
            }else {
           	 // Failure retrieving MAC address
            	Toast.makeText(this, R.string.macFailed, Toast.LENGTH_SHORT).show();
            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth is now enabled
            } else {
                // User did not enable Bluetooth or an error occured
                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                finish();
            }
            break;
        case REQUEST_ENTER_PID:
        	Toast.makeText(this, "PID venster gesloten", Toast.LENGTH_SHORT).show();
        	break;
        case REQUEST_SENSOR:
        	Toast.makeText(this, "Sensor venster gesloten", Toast.LENGTH_SHORT).show();
        }
    }
    
    //
    public static void write(byte data) {
    	if (outStream != null) {
    		try {
    			outStream.write(data);
    		} catch (IOException e) {
    		}
    	}
    }
	
	//Read routine die 2 bytes leest en deze teruggeeft als signed.
	/*public int readSigned() {
		if (binStream != null) {
			try {
				byte[] buff = new byte[2];
				int c = binStream.read(buff);
				if(c == 2){
					int i = (int)buff[0];
					int j = (int)buff[1];
					if(j<0){
						j += 256;
					}
					return ((i << 8)+ j);
				} else {
				}
				
			} catch (IOException e) {
			}
		}
		return -1;
	}*/
    
    public void emptyOutStream() {
   	 if (outStream != null) {
            try {
           	 outStream.flush();
            } catch (IOException e) {
            }
        }
    }
    
    public void connect() {
   	 // Launch the DeviceListActivity to see devices and do scan
        Intent serverIntent = new Intent(this, DeviceListActivity.class);
        startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
    }
    
    public void disconnect() {
   	 if (outStream != null) {
   		 try {
   	 			outStream.close();
   	 			//binStream.close();
   	 			connectStat = false;
   				//connectitem.setTitle(R.string.disconnected);
   	 		} catch (IOException e) {
   	 		}
   	 } 
    }
    /*public int streamAvailable(){
    	if (binStream != null){
    		try {
    			return binStream.available();
    		} catch (IOException e) {
    		}
    		
    	}
    	return -1;
    }*/
    
    //Schrijf sensornaam en as naar outputstream, en wacht totdat er 2 bytes zijn teruggekomen.
    /*public int getSensorData(char sensor, char as)throws IOException{
    	int data = 0;
    		write((byte)sensor);
    		write((byte)as);
    		while(streamAvailable() != 2){
    			if(streamAvailable()>2){
    				throw new IOException();
    			}
    		}
    		data = readSigned();
    	return data;
    }*/
    
    //Menu aanroepen
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.option_menu, menu);
	    return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item){
		//Afhandelen van itemselectie
		switch (item.getItemId()) {
		case R.id.connect:
			if (connectStat) {
				// Attempt to disconnect from the device
				disconnect();
			}else{
				// Attempt to connect to the device
				connect();
			}
			return true;
		case R.id.instellen:
			instellen();
			return true;
		case R.id.sensoren:
			sensoren();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	@Override 
	public void onDestroy() { 
	 emptyOutStream();
	    disconnect();
	    if (mSensorListener != null) {
       	 mySensorManager.unregisterListener(mSensorListener);
        }
	    super.onDestroy(); 
	}
	@Override 
    public void onResume() { 
         super.onResume();
         mySensorManager.registerListener(mSensorListener, accSensor, SensorManager.SENSOR_DELAY_GAME);
    } 
	
	//nieuwe code vanaf hier
	private class BluetoothSocketListener implements Runnable {

		private BluetoothSocket socket;
		private Handler handler;
		private InputStream inStream;

		public BluetoothSocketListener(BluetoothSocket socket, Handler handler) {
			this.socket = socket;
			this.handler = handler;
		}

		public void run() {
			try {
				inStream = socket.getInputStream();
				// Keep listening to the InputStream while connected

				while (true) {
					try {
						int bufferSize = 1024;
						byte[] buffer = new byte[bufferSize];

						// Read from the InputStream
						int bytesRead = inStream.read(buffer);
						String message = new String(buffer, 0, bytesRead);
						
						// Send the obtained bytes to the UI Activity
						handler.post(new MessagePoster("Text=" + message + " "
								+ "Bytes read=" + bytesRead));

						//Zend bytes naar Sensorposter
						
						if (sensormodus) {
							handler.post(new SensorPoster(buffer, bytesRead));
						}
						
					} catch (IOException e) {
						Log.e(TAG, "disconnected", e);
						break;
					}
				}

			} catch (IOException e) {
				Log.d("BLUETOOTH_COMMS", e.getMessage());
			}
		}
	}

	private class MessagePoster implements Runnable {
		private TextView textView;
		private String message;

		public MessagePoster(String message) {
			this.textView = debug;
			this.message = message;
		}

		public void run() {
			textView.setText(message);
		}
	}
	
	private class SensorPoster implements Runnable {
		private int bytesread;
		private byte[] bytes;
		
		public SensorPoster( byte[] bytes, int bytesread){

			this.bytes = bytes;
			this.bytesread = bytesread;
		}
		
		public void run() {
			
			if (bytesread > 0) {
				//sensoren.setWaarden((int) bytes[0]);
				//setSensorModus(false);
				sensoren.setXYZ(bytes, bytesread);
			}
		}
	}
	public static void setSensorModus(boolean mod){
		sensormodus = mod;
	}
	
	public static void setPidProgModus(boolean mod){
		pidprogmodus = mod;
	}
	
	private final SensorEventListener mSensorListener = new SensorEventListener() {
   	 
 		@Override
 		public void onAccuracyChanged(Sensor sensor, int accuracy) {}
 		
 		@Override
 		public void onSensorChanged(SensorEvent event) {
 			// Checks whether to send steering command or not
 			long date = System.currentTimeMillis();
 			if (date - lastWrite > MOVE_TIME) {
 				//X sensor
 				if (event.values[0] > 0.4) {
 					// Rechtsom
 					stuurBar.setProgress(stuur_value_init - (int)(event.values[0]*5));
 				}else if (event.values[0] < -0.4) {
 					// Linksom
 					stuurBar.setProgress(stuur_value_init - (int)(event.values[0]*5));
 				}else {
 					// Doe Niets
 					stuurBar.setProgress(stuur_value_init);
 				}
 				
 				//Y sensor
 				if (event.values[1] > 1.0) {
 					// Vooruit
 					voorAchterBar.setProgress(va_value_init - (int)(event.values[1]*5));
 				}else if (event.values[1] < -1.0) {
 					// Achteruit
 					voorAchterBar.setProgress(va_value_init - (int)(event.values[1]*5));
 				}else {
 					// Doe Niets
 					voorAchterBar.setProgress(va_value_init);
 				}
 				lastWrite = date;
 			}
 		}
      };
}