package eindp.helikopter.hekoco;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class instellen extends Activity {
	Button pidlezen;
	Button pidschrijven;
	EditText pText;
	EditText iText;
	EditText dText;
	char pValue;
	char iValue;
	char dValue;
	TextView progStatus;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
		setContentView(R.layout.instellen);
		
		setResult(Activity.RESULT_CANCELED);

		progStatus = (TextView)findViewById(R.id.progStatus);
		pText = (EditText)findViewById(R.id.pValue);
        iText = (EditText)findViewById(R.id.iValue);
        dText = (EditText)findViewById(R.id.dValue);
        pidlezen = (Button)findViewById(R.id.PID_lezen);
        pidschrijven = (Button)findViewById(R.id.PID_schrijven);
        
		pidlezen.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(HeKoCo.getConnectStat()){
					progStatus.setText("Waarden gelezen");
				} else {
					progStatus.setText("Geen device gekoppeld");
				}
			}
		});
		
		pidschrijven.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (HeKoCo.getConnectStat()) {
					try {
						pValue = (char)Integer.parseInt(pText.getText().toString());
						iValue = (char)Integer.parseInt(iText.getText().toString());
						dValue = (char)Integer.parseInt(dText.getText().toString());
						progStatus.setText("P: " + pValue + " I: " + iValue
								+ " D: " + dValue);
						//converteer char naar byte array
						byte [] p = { (byte)((pValue >> 8) & 0xff), (byte)(pValue  & 0xff) };
						byte [] i = { (byte)((iValue >> 8) & 0xff), (byte)(iValue  & 0xff) };
						byte [] d = { (byte)((dValue >> 8) & 0xff), (byte)(dValue  & 0xff) };
				        
						//schrijf identifier en bytes.
						HeKoCo.setPidProgModus(true);
						HeKoCo.write((byte)'P');
						HeKoCo.write(p[0]);
						HeKoCo.write(p[1]);
						HeKoCo.write((byte)'I');
						HeKoCo.write(i[0]);
						HeKoCo.write(i[1]);
						HeKoCo.write((byte)'D');
						HeKoCo.write(d[0]);
						HeKoCo.write(d[1]);
						HeKoCo.setPidProgModus(false);
						
					} catch (NumberFormatException e) {
						progStatus.setText("Error: Vul waarden in...");
					}
				} else {
					progStatus.setText("Geen device gekoppeld");
				}
			}
		});
	}
	
}
