package eindp.helikopter.hekoco;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class sensoren extends Activity {
	Button gyrolezen;
	Button accelerolezen;
	static byte[] buff = new byte[16];
	static int pos = 0;
	static EditText X;
	static EditText Y;
	static EditText Z;
	static int xValue = 0;
	static int yValue = 0;
	static int zValue = 0;
	TextView sensor_debug;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
		setContentView(R.layout.sensoren);
		
		setResult(Activity.RESULT_CANCELED);

		sensor_debug = (TextView)findViewById(R.id.sensor_debug);
		X = (EditText)findViewById(R.id.xValue);
        Y = (EditText)findViewById(R.id.yValue);
        Z = (EditText)findViewById(R.id.zValue);
        gyrolezen = (Button)findViewById(R.id.GyroLezen);
        accelerolezen = (Button)findViewById(R.id.AcceleroLezen);
        
        gyrolezen.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				HeKoCo.setSensorModus(true);
				HeKoCo.write((byte)'g');
			}
		});
		
        accelerolezen.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				HeKoCo.setSensorModus(true);
				HeKoCo.write((byte)'a');
				//HeKoCo.write((byte)'x');
			}
		});
	}
	
	public void OnStop(){
		HeKoCo.setSensorModus(false);
	}
	
	public void OnDestroy(){
		HeKoCo.setSensorModus(false);
	}
	
//	momenteel overbodig
	public static void setWaarden(int xWaarde){
		xValue = xWaarde;
		X.setText("" + xValue);
	}
	
	public static void setXYZ(byte[] ontv, int len){
		int i;
		for(i=pos; i<(len+pos); i++){
			buff[i] = ontv[i-pos];
		}
		pos = i;
		if( pos > 2){
			pos = 0;
			xValue = (int)buff[0];
			yValue = (int)buff[1];
			zValue = (int)buff[2];
			X.setText("" + xValue);
			Y.setText("" + yValue);
			Z.setText("" + zValue);
			HeKoCo.setSensorModus(false);
		}
	}
}
