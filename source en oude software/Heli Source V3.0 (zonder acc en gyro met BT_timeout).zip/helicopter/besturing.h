/*
 * besturing.h
 *
 *  Created on: 17 jun. 2011
 *      Author: dirkjan
 */

#ifndef BESTURING_H_
#define BESTURING_H_

void besturing_init(void);
void besturing_task(unsigned char ovf);

#define BT_TIMEOUT	1000


#endif /* BESTURING_H_ */
