/*
 * regelaar.c
 *
 *  Created on: 21 jun. 2011
 *      Author: dirkjan
 */

#include "regelaar.h"
#include "motorsturing.h"

static signed char	ovf_counter,
					CommandStaart,
					CommandDraai,
					lock_motors,
					outputStaart,
					outputLift,
					outputDraai;

static unsigned char CommandLift;

static unsigned int call_count, sensor_access_count, calls, sensor_accesses;
static unsigned int pGain = 2, iGain, dGain;


void regelaar_init(){
	lock_motors = 0;
	init_motors();
//	TWI_Master_Initialise();
//	while (write_to_reg(ACCEL_WRITE_ADDRESS, ACCEL_CTRL_1, ACCEL_NO_SLEEP_MASK));		// zorgen dat de accelero niet in slaap valt
//	while (write_to_reg(GYRO_WRITE_ADDRESS, GYRO_CTRL_1, GYRO_INIT_MASK));				// zorgen dat de gyro niet in slaap valt
}

void lock_motor_driver(signed char lock){
	lock_motors = lock;
}

void regelaar_task(unsigned char ovf){
	if(ovf){
		ovf_counter++;
	}

	call_count++;
	if(call_count > 1000){
		call_count=0;
		calls++;
	}

	if(sensor_access_count > 1000){
		sensor_access_count=0;
		sensor_accesses++;
	}


	outputStaart	= CommandStaart;
	outputLift		= 155+CommandLift;		//gaat van 155 tot 255
	outputDraai 	= CommandDraai;

	if (lock_motors||outputLift==0){
		set_speed_motor(STAARTROTOR,0);
		set_speed_motor(ONDERROTOR,0);
		set_speed_motor(BOVENROTOR,0);
	}else{
		set_tail_rotor(outputStaart, outputLift);
		set_main_rotors(outputLift, outputDraai);
	}
}

void set_offset_draai(signed char offset){
	if (offset>DRAAI_OFFSET_MAX)
		CommandDraai=DRAAI_OFFSET_MAX;
	else if (offset<-DRAAI_OFFSET_MAX)
		CommandDraai=-DRAAI_OFFSET_MAX;
	else
		CommandDraai = offset;
	//CommandDraai/=2;
	//CommandDraai+=25;
}

void set_offset_lift(signed char offset){
	if (offset>100)
		CommandLift = 100;
	else
		CommandLift = offset;

}

void set_offset_staart(signed char offset){
	if (offset>100)
		CommandStaart = 100;
	else
		CommandStaart = offset;
}


void set_P(unsigned int value){
	pGain	= value;
}

void set_I(unsigned int value){
	iGain	= value;
}

void set_D(unsigned int value){
	dGain	= value;
}
