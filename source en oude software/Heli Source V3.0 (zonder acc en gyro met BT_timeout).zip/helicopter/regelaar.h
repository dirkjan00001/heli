/*
 * regelaar.h
 *
 *  Created on: 21 jun. 2011
 *      Author: dirkjan
 */

#ifndef REGELAAR_H_
#define REGELAAR_H_

#define I2C_READ_MASK		0x01

#define X_AXIS	'x'
#define Y_AXIS	'y'
#define Z_AXIS	'z'

#define GYRO_XDATA_L	0x28
#define GYRO_XDATA_H	0x29
#define GYRO_YDATA_L	0x2A
#define GYRO_YDATA_H	0x2B
#define GYRO_ZDATA_L	0x2C
#define GYRO_ZDATA_H	0x2D

#define GYRO_TEMP		0x26

#define ACCEL_XDATA	0x29
#define ACCEL_YDATA	0x2B
#define ACCEL_ZDATA	0x2D

#define GYRO_CTRL_1			0x20
#define GYRO_CTRL_4			0x23
#define GYRO_STATUS_REG		0x27

#define ACCEL_CTRL_1		0x20

#define GYRO_DATA_AVAILABLE	0x08
#define GYRO_NO_SLEEP_MASK	0x80
#define GYRO_INIT_MASK		0x0F
#define GYRO_SCALE_MAX		0x30
#define AUTO_INC_MASK		0x80
#define ACCEL_NO_SLEEP_MASK	0x70

#define GYRO_READ_ADDRESS	0xD3
#define GYRO_WRITE_ADDRESS	0xD2
#define ACCEL_READ_ADDRESS	0x39
#define ACCEL_WRITE_ADDRESS	0x38

#define DEVICE_BUSY		0x01
#define WRITE_FAILED	0x02

#define DRAAI_OFFSET_MAX	50


void regelaar_init();							// wordt uitgevoerd bij initialiseren
void regelaar_task(unsigned char ovf);			// uitgevoerd in oneindig lange loop

void sensortest();

unsigned char write_to_reg(unsigned char dev_id, unsigned char reg_addr, unsigned char data);
unsigned char get_accel_data_from_sensor(unsigned char reg_addr, signed char *acceldata, unsigned char dev_id);	// read data from sensor
unsigned char get_gyro_data_from_sensor(unsigned char reg_addr, unsigned char *acceldata, unsigned char dev_id);	// read data from sensor

signed char get_accelero_data(char as);	// read data from uC memory
signed char get_gyro_data(char as);
signed char get_temp();

void lock_motor_driver(signed char lock);

void PID_update();
void read_sensors();

//offsets todo autimatisch detecteren offsets
void set_offset_draai(signed char offset);
void set_offset_lift(signed char offset);
void set_offset_staart(signed char offset);

// pid waarddes instellen
void set_P(unsigned int value);
void set_I(unsigned int value);
void set_D(unsigned int value);

#endif /* REGELAAR_H_ */
