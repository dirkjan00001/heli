/*
 * besturing.h
 *
 *  Created on: 17 jun. 2011
 *      Author: dirkjan
 */

#ifndef BESTURING_H_
#define BESTURING_H_

void besturing_init(void);
void besturing_task(void);


#endif /* BESTURING_H_ */
