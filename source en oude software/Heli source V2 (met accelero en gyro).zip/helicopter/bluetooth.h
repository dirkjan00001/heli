/*
 * bluetooth.h
 *
 *  Created on: 16 jun. 2011
 *      Author: dirkjan
 */

#ifndef BLUETOOTH_H_
#define BLUETOOTH_H_

#define USART_DATA_READY (UCSR0A & (1<<RXC0))

#define BAUD_DEFAULT 	19200
#define DEFAULT_UBRR	(F_CPU/16/BAUD_DEFAULT-1)


#define send_data_buff_len			100
#define receive_data_buff_len		20

void blue_init(void);
void blue_task();	// voert bluetooth taken uit
void bluetooth_send_char(unsigned char data);
void bluetooth_send_text (char *s);
void bluetooth_send_nr(signed int nummer);
unsigned char bluetooth_get_data(void);
unsigned char bluetooth_data_ready(void);
#endif /* BLUETOOTH_H_ */
