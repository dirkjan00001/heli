/*
 * main.c
 *
 *  Created on: 16 jun. 2011
 *      Author: dirkjan
 */

#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "besturing.h"
#include "regelaar.h"
#include "main.h"

volatile unsigned char timer_overflow = 0;

ISR(TIMER1_COMPA_vect){
	timer_overflow = 1;
}

void init(void) {
	DDRC=(1<<PC3);
	PORTC|=(1<<PC3);

	TCCR1B = (1<<WGM12)|(1<<CS11);
	OCR1A = 461;
	TIMSK1=(1<<OCIE1A);

	sei();

	besturing_init();

	_delay_ms(200);
	PORTC&=~(1<<PC3);

}

int main(void) {
	init();
	unsigned char ovf=0;
	unsigned int teller=0;

	while (1) {
		if (timer_overflow){
			timer_overflow=0;
			ovf=1;
			teller++;
		}

		if (teller ==900){
			PORTC |=(1<<PC3);
		}else if (teller >=1000){
			PORTC&=~(1<<PC3);
			teller =0;
		}

		besturing_task();
		regelaar_task(ovf);

		ovf=0;
	}

	return 0;
}
