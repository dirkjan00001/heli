/*
 * motorsturing.h
 *
 *  Created on: 27 jun. 2011
 *      Author: dirkjan
 */

#ifndef MOTORSTURING_H_
#define MOTORSTURING_H_

#define STAARTROTOR	1
#define ONDERROTOR	2
#define BOVENROTOR	3


void init_motors(void);
unsigned char get_speed_motor(unsigned char motor);
unsigned char set_speed_motor(unsigned char motor,unsigned char speed);

void set_main_rotors(unsigned char throttle, signed char delta);
void set_tail_rotor(unsigned char speed, unsigned char main_throttle);

#endif /* MOTORSTURING_H_ */
